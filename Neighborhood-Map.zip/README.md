## How to use
1. Open to folder where files are at
2. Open `index.html` in your browser
3. Test out the list and the map by selecting on the list section or the markers on the map